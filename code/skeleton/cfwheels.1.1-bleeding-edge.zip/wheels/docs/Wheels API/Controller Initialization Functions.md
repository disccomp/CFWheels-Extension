# Controller Initialization Functions
			
## Caching Functions
				
				
* [caches()](caches.md)
			
## Filtering Functions
				
				
* [filterChain()](filterChain.md)
* [filters()](filters.md)
* [setFilterChain()](setFilterChain.md)
			
## Provides Functions
				
				
* [provides()](provides.md)
			
## Rendering Functions
				
				
* [usesLayout()](usesLayout.md)
			
## Verification Functions
				
				
* [setVerificationChain()](setVerificationChain.md)
* [verificationChain()](verificationChain.md)
* [verifies()](verifies.md)
