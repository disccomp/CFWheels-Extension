# isAjax()

## Description
Returns whether the page was called from JavaScript or not.

## Function Syntax
	isAjax(  )



## Examples
	
		<cfset requestIsAjax = isAjax()>
