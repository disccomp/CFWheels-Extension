# isPost()

## Description
Returns whether the request came from a form `POST` submission or not.

## Function Syntax
	isPost(  )



## Examples
	
		<cfset requestIsPost = isPost()>
