# flashClear()

## Description
Deletes everything from the Flash.

## Function Syntax
	flashClear(  )



## Examples
	
		<cfset flashClear()>
