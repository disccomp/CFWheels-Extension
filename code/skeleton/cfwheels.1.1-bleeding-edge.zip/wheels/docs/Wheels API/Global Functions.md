# Global Functions
			
## Miscellaneous Functions
				
				
* [controller()](controller.md)
* [deobfuscateParam()](deobfuscateParam.md)
* [l()](l.md)
* [mimeTypes()](mimeTypes.md)
* [model()](model.md)
* [obfuscateParam()](obfuscateParam.md)
* [pluginNames()](pluginNames.md)
* [semanticVersioning()](semanticVersioning.md)
* [timestamp()](timestamp.md)
* [URLFor()](URLFor.md)
			
## String Functions
				
				
* [capitalize()](capitalize.md)
* [humanize()](humanize.md)
* [hyphenize()](hyphenize.md)
* [pluralize()](pluralize.md)
* [singularize()](singularize.md)
* [toXHTML()](toXHTML.md)
