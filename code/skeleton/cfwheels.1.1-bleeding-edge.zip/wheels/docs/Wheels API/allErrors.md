# allErrors()

## Description
Returns an array of all the errors on the object.

## Function Syntax
	allErrors(  )



## Examples
	
		<!--- Get all the errors for the `user` object --->
		<cfset errorInfo = user.allErrors()>
