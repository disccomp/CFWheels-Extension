# flashInsert()

## Description
Inserts a new key/value into the Flash.

## Function Syntax
	flashInsert(  )



## Examples
	
		<cfset flashInsert(msg="It Worked!")>
