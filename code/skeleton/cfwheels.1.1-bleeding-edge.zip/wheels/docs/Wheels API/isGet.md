# isGet()

## Description
Returns whether the request was a normal `GET` request or not.

## Function Syntax
	isGet(  )



## Examples
	
		<cfset requestIsGet = isGet()>
