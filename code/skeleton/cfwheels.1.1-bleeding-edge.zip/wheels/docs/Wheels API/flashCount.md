# flashCount()

## Description
Returns how many keys exist in the Flash.

## Function Syntax
	flashCount(  )



## Examples
	
		<cfif flashCount() gt 0>
			do something...
		</cfif>
