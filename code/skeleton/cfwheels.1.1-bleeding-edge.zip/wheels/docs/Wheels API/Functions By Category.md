# Functions By Category

1. [Configuration Functions](Configuration Functions.md)
2. [Controller Initialization Functions](Controller Initialization Functions.md)
3. [Controller Request Functions](Controller Request Functions.md)
4. [Global Functions](Global Functions.md)
5. [Model Class Functions](Model Class Functions.md)
6. [Model Initialization Functions](Model Initialization Functions.md)
7. [Model Object Functions](Model Object Functions.md)
8. [View Helper Functions](View Helper Functions.md)
