# Configuration Functions
			
## Caching Functions
				
				
* [setCacheSettings()](setCacheSettings.md)
			
## Defaults Functions
				
				
* [get()](get.md)
* [set()](set.md)
			
## Formats Functions
				
				
* [addFormat()](addFormat.md)
			
## Routes Functions
				
				
* [addDefaultRoutes()](addDefaultRoutes.md)
* [addRoute()](addRoute.md)
