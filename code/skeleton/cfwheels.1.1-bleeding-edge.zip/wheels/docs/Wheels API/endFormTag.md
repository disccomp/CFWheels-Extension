# endFormTag()

## Description
Builds and returns a string containing the closing `form` tag.

## Function Syntax
	endFormTag(  )



## Examples
	
		<!--- view code --->
		<cfoutput>
		    #startFormTag(action="create")#
		        <!--- your form controls --->
		    #endFormTag()#
		</cfoutput>
